### Requirements

```
python 3.7.4
mpi4py 3.0.2
numpy 1.21.6
pandas 1.3.5
```

**Data files should be in the `data` folder which is in the same directory with `main.py`.**

### Run locally

```
mpiexec -n [NUM_PROCESSES] python main.py [DATA]

# Process bigTwitter.json as default
mpiexec -n 8 python main.py

# e.g.
mpiexec -n 1 python main.py tiny

mpiexec -n 4 python main.py small

mpiexec -n 8 python main.py big
```

### Run on Spartan

| Resource                                    | Slurm      | Output   |
| ------------------------------------------- | ---------- | -------- |
| 1 node and 1 core                           | 1n1c.slurm | 1n1c.out |
| 1 node and 8 cores                          | 1n8c.slurm | 1n8c.out |
| 2 nodes and 8 cores (with 4 cores per node) | 2n8c.slurm | 2n8c.out |

`sbatch 1n1c.slurm`
`sbatch 1n8c.slurm`
`sbatch 2n8c.slurm`
